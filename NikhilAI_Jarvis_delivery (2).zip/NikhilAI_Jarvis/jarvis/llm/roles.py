"""
Role-based model router + fallback manager
=========================================

Har role (brain / fast / planner / code / research / extract / vision / browser / critic) ke liye
ek **chain** banti hai:

    1. Runtime settings / env override        (sabse pehle — owner ne jo bola)
    2. Provider ke configured defaults        (free models pehle)
    3. Live discovery se best free model      (agar kuch bhi available na ho)
    4. Doosre providers ka cross-fallback     (brain: OpenRouter → Gemini → Groq)

Isliye ek model 404 de ya quota khatam ho, poora agent rukta nahi — agla model chalta hai.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from ..config import runtime as R
from ..config import settings as S
from . import discovery as D
from . import providers as P

_HISTORY: list[dict[str, Any]] = []          # provider/model attempts (observability)
_LOCK = threading.RLock()
_CROSS_ORDER = ("openrouter", "gemini", "groq", "openai", "anthropic", "xai", "ollama")
_RETIRED_MARKERS = ("2.0-flash", "gemini-2.0", "text-bison", "gpt-3.5-turbo-0301")
_ROLE_TEMP = {"brain": 0.3, "fast": 0.0, "planner": 0.2, "code": 0.1, "research": 0.2,
              "extract": 0.0, "vision": 0.1, "browser": 0.1, "critic": 0.0}


@dataclass
class ModelTarget:
    provider: str
    model: str

    def __str__(self) -> str:
        return f"{self.provider}:{self.model}"


@dataclass
class ResolvedRoute:
    role: str
    targets: list[ModelTarget] = field(default_factory=list)
    temperature: float = 0.2
    reason: str = ""

    @property
    def primary(self) -> ModelTarget | None:
        return self.targets[0] if self.targets else None

    def describe(self) -> str:
        if not self.targets:
            return "(no model — offline demo mode)"
        head = str(self.targets[0])
        if len(self.targets) > 1:
            return f"{head}  (+{len(self.targets) - 1} fallback)"
        return head

    def as_dict(self) -> dict[str, Any]:
        return {"role": self.role, "targets": [str(t) for t in self.targets],
                "temperature": self.temperature, "reason": self.reason}


def active_provider() -> str:
    """Configured provider first; explicit choices never silently fall through to another brain."""
    override = str(R.get("provider") or "").strip().lower()
    configured = P.canonical(override) if override and override != "auto" else ""
    if not configured:
        env_choice = P.canonical(getattr(S, "BRAIN_PROVIDER_CONFIG", "auto"))
        configured = env_choice if env_choice != "auto" else ""
    if configured:
        # A missing key is reported as demo/unavailable, not replaced by another configured key.
        return configured if P.is_available(configured) else "demo"
    live = S._auto_provider() if hasattr(S, "_auto_provider") else S.autodetect_provider()
    return live if live != "demo" and P.is_available(live) else "demo"


def _retired(model: str) -> bool:
    low = model.lower()
    return any(marker in low for marker in _RETIRED_MARKERS)


def _valid_for_provider(model: str, provider: str) -> bool:
    """Reject retired and obviously cross-provider model IDs before constructing a client."""
    if not model or _retired(model):
        return False
    low = model.strip().lower()
    provider = P.canonical(provider)
    if provider == "openrouter":
        return "/" in low or low == "auto"
    if provider == "gemini":
        return low.startswith(("gemini", "gemma"))
    if provider == "anthropic":
        return low.startswith("claude-")
    if provider == "xai":
        return low.startswith("grok-")
    if provider == "openai":
        return low.startswith(("gpt-", "o1", "o3", "o4", "chatgpt-"))
    if provider == "groq":
        # Groq also hosts namespaced openai/gpt-oss, qwen, and other vendor models.
        # Bare model IDs owned by Gemini/Anthropic/xAI/OpenAI are not Groq routes.
        if "/" not in low and low.startswith(("gemini", "gemma", "claude-", "grok-", "gpt-", "o1", "o3", "o4")):
            return False
        return True
    return True


def cross_provider_chain(role: str) -> list[ModelTarget]:
    """Use each fallback provider's own defaults; never pair one provider with another's model ID."""
    out: list[ModelTarget] = []
    for provider in _CROSS_ORDER:
        if not P.is_available(provider):
            continue
        for model in S.provider_model_defaults(role, provider)[:2]:
            if _valid_for_provider(model, provider):
                out.append(ModelTarget(provider, model))
    return out


def resolve(role: str, allow_discovery: bool = True) -> ResolvedRoute:
    """Role ke liye pura fallback chain resolve karo (offline me khali route)."""
    configured_temperature = R.get("temperature")
    temperature = (_ROLE_TEMP.get(role, 0.2) if configured_temperature is None
                   else float(configured_temperature))
    runtime_choice = P.canonical(str(R.get("provider") or "auto"))
    env_choice = P.canonical(getattr(S, "BRAIN_PROVIDER_CONFIG", "auto"))
    explicit_provider = runtime_choice != "auto" or env_choice != "auto"
    provider = active_provider()
    if provider == "demo":
        chosen = runtime_choice if runtime_choice != "auto" else env_choice
        if chosen != "auto" and not P.is_available(chosen):
            reason = f"configured provider '{chosen}' has no key; no provider switch performed"
        else:
            reason = "offline/demo mode; no configured provider key"
        return ResolvedRoute(role, [], temperature, reason=reason)

    reason_bits: list[str] = []
    local: list[ModelTarget] = []
    runtime_model = str(R.get("model") or "").strip() if role == "brain" else ""
    env_model = S.explicit_model_for(role)
    requested_model = runtime_model or env_model
    if requested_model and not _valid_for_provider(requested_model, provider):
        source = "runtime model override" if runtime_model else f"{role.upper()}_MODEL"
        return ResolvedRoute(
            role, [], temperature,
            reason=f"{source} '{requested_model}' is retired or incompatible with configured provider '{provider}'; no substitute selected",
        )

    if runtime_model:
        local.append(ModelTarget(provider, runtime_model))
        reason_bits.append("runtime override")

    for model in S.model_chain_for(role, provider):
        if _valid_for_provider(model, provider):
            local.append(ModelTarget(provider, model))
    if local and "runtime override" not in reason_bits:
        reason_bits.append(f"{provider} configured route")

    # Live discovery only fills an empty configured route; it never replaces a chosen model.
    if allow_discovery and not local:
        best = D.best_free_model(provider, role)
        if best:
            local.append(ModelTarget(provider, best))
            reason_bits.append("live discovery")

    def _unique(items: list[ModelTarget]) -> list[ModelTarget]:
        out: list[ModelTarget] = []
        seen: set[tuple[str, str]] = set()
        for target in items:
            key = (target.provider, target.model)
            if key not in seen:
                out.append(target)
                seen.add(key)
        return out

    local = _unique(local)
    if not local:
        return ResolvedRoute(role, [], temperature, reason=", ".join(reason_bits) or "no model route")

    # Keep the preferred model first, one same-provider fallback second, then spread the
    # remaining bounded attempts across other configured providers. This avoids spending
    # a whole request budget on several stale models from one provider.
    # Cross-provider fallback is an auto-mode convenience; explicit owner choices stay pinned.
    cross = [] if explicit_provider else _unique(
        [target for target in cross_provider_chain(role) if target.provider != provider]
    )
    ordered = [local[0]]
    if len(local) > 1:
        ordered.append(local[1])
    ordered.extend(cross)
    ordered.extend(local[2:])
    ordered = _unique(ordered)[:S.MAX_MODEL_TARGETS]
    if cross:
        reason_bits.append("cross-provider fallback")
    return ResolvedRoute(role, ordered, temperature, reason=", ".join(reason_bits) or "configured")


# ---------------------------------------------------------------------------
# observability
# ---------------------------------------------------------------------------
def note_attempt(role: str, provider: str, model: str, ok: bool, error: str = "", ms: int = 0) -> None:
    with _LOCK:
        _HISTORY.append({
            "ts": __import__("time").strftime("%H:%M:%S"),
            "role": role, "provider": provider, "model": model,
            "ok": ok, "error": (error or "")[:200], "ms": ms,
        })
        if len(_HISTORY) > 200:
            del _HISTORY[:-200]


def attempts(limit: int = 20) -> list[dict[str, Any]]:
    with _LOCK:
        return list(_HISTORY[-limit:])


def health() -> dict[str, Any]:
    """Provider health — doctor ke liye."""
    out: dict[str, Any] = {"active": active_provider(), "available": P.available(), "roles": {}}
    for role in S.MODEL_ROLES:
        route = resolve(role, allow_discovery=False)
        out["roles"][role] = route.describe()
    return out
