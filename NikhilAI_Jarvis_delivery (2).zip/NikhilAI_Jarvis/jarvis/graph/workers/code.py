"""Code generation, execution, and verified artifact worker."""
from __future__ import annotations

import time
from typing import Any

from ..state import JarvisState
from .common import _event, _finding, _permission_block


async def code_worker(state: JarvisState) -> dict[str, Any]:
    """Code likho → chalao → error par khud fix karo (self-healing)."""
    blocked = _permission_block(state, "code", "code_engine")
    if blocked:
        return blocked
    request = state.get("request", "")
    refine_hint = state.get("refine_hint", "")
    task = f"{request}\n\nRefine hint: {refine_hint}" if refine_hint else request
    done_actions = dict(state.get("done_actions", {}) or {})
    action_args = {"task": task, "language": "python", "run": True}
    started = time.time()
    from ...tools.code_engine import code_engine_run
    from ..idempotency import completed_action, remember_completed_action

    cached = completed_action(done_actions, "code_engine", action_args)
    if cached and isinstance(cached.get("result"), dict):
        outcome = dict(cached["result"])
    else:
        outcome = await code_engine_run(task=task, language="python", run=True)
        if outcome.get("ok"):
            remember_completed_action(
                done_actions, "code_engine", action_args, outcome,
                output=str(outcome.get("report", "")), worker="code",
            )
    summary = (
        f"task: {request[:200]}\n"
        f"script: {outcome.get('script')}\n"
        f"attempts: {outcome.get('attempts')}\n"
        f"ok: {outcome.get('ok')}\n\n"
        f"{outcome.get('report', '')[:5000]}"
    )
    code_evidence = [{
        "worker": "code", "name": "code_engine", "args": action_args,
        "output": str(outcome.get("report", ""))[:800] or "(koi output nahi)",
        "ok": bool(outcome.get("ok")), "source": "deterministic",
    }]
    return {
        "findings": [_finding("code", summary, artifacts=outcome.get("artifacts", []),
                              seconds=round(time.time() - started, 1), ok=outcome.get("ok"),
                              tool_calls=code_evidence)],
        "artifacts": outcome.get("artifacts", []),
        "execution_required": True,           # code worker hamesha asli execution hai
        "tool_evidence": code_evidence,
        "done_actions": done_actions,
        "events": [_event(state, "code_worker", f"{outcome.get('attempts')} attempts • ok={outcome.get('ok')}")],
    }
