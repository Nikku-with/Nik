"""
Unified agent runner — CLI, voice, Telegram, API sab yahi use karte hain
=======================================================================

`run_agent(text, session_id, surface)` ek hi entry point hai: LangGraph chalta hai, memory update
hoti hai, permissions apply hote hain, events trace hote hain, aur ek structured result milta hai.

Kyun ek hi runner: voice/text/telegram ke alag-alag brain banane se behaviour diverge ho jata hai
aur bugs teen jagah fix karne padte hain. Yahan sab ek hi graph + ek hi memory + ek hi tools use
karte hain — bas session aur permission level alag hota hai.
"""
from __future__ import annotations

import asyncio
import re
import time
from collections.abc import AsyncIterator
from dataclasses import asdict, dataclass, field
from typing import Any

from ..config import settings as S
from ..memory.session_state import get_state
from ..voice.speech import for_speech, summary_for_speech


@dataclass
class AgentResult:
    request: str
    answer: str = ""
    spoken: str = ""
    plan: list[str] = field(default_factory=list)
    workers: list[str] = field(default_factory=list)
    reasoning: list[str] = field(default_factory=list)   # structured PLAN/DECISION/ACTION/RESULT lines
    events: list[dict[str, Any]] = field(default_factory=list)
    findings: list[dict[str, Any]] = field(default_factory=list)
    artifacts: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    iterations: int = 0
    critique: dict[str, Any] = field(default_factory=dict)
    requirements: dict[str, dict[str, Any]] = field(default_factory=dict)
    seconds: float = 0.0
    session_id: str = "default"
    surface: str = "cli_owner"
    status: str = "done"
    blocked_tools: list[str] = field(default_factory=list)
    memory_updates: list[str] = field(default_factory=list)
    # ---- execution evidence (hard invariant: success bina proof ke nahi) --------------
    tool_evidence: list[dict[str, Any]] = field(default_factory=list)   # asli tool records
    execution_required: bool = False                                    # kaam ke liye tool zaroori tha?
    verified_execution: bool = False                                    # evidence mila + koi fail nahi
    memory_persisted: bool = False                                      # graph ya runner ne turn save kiya
    task_id: str = ""                                                    # shared task row; no duplicate task insert
    run_id: str = ""                                                     # scheduler trigger identity

    @property
    def tool_calls_flat(self) -> list[dict[str, Any]]:
        """Saare tool records ek list me (findings + worker-level evidence)."""
        out = [rec for rec in (self.tool_evidence or []) if isinstance(rec, dict)]
        for f in (self.findings or []):
            for rec in (f.get("tool_calls") or []) if isinstance(f, dict) else []:
                if isinstance(rec, dict):
                    out.append(rec)
        return out

    def recompute_execution_flags(self) -> None:
        """flags ko evidence se dobara nikalo — koi bhi code path inhe fake true na kar sake.

        (Manual set nahi: sirf `tool_evidence`/findings se, aur success ke liye kam se kam
        ek ok record + koi failed record nahi.)
        """
        from ..runtime.evidence import supporting_records

        records = self.tool_calls_flat
        ok = supporting_records(records)          # khali search (found=False) success nahi hai
        failed = [r for r in records if not r.get("ok")]
        self.verified_execution = bool(ok) and not failed

    def as_dict(self) -> dict[str, Any]:
        return {
            "request": self.request, "response": self.answer, "answer": self.answer,
            "spoken": self.spoken, "plan": self.plan, "selected_workers": self.workers,
            "workers": self.workers, "reasoning": self.reasoning, "events": self.events,
            "findings": self.findings, "artifacts": self.artifacts, "errors": self.errors,
            "iterations": self.iterations, "critique": self.critique, "requirements": self.requirements,
            "seconds": self.seconds,
            "session_id": self.session_id, "surface": self.surface, "status": self.status,
            "blocked_tools": self.blocked_tools,
            "execution_required": self.execution_required,
            "verified_execution": self.verified_execution,
            "memory_persisted": self.memory_persisted, "task_id": self.task_id,
            "run_id": self.run_id, "tool_evidence": self.tool_calls_flat[:24],
            "memory_updates": self.memory_updates,
        }


# ---------------------------------------------------------------------------
# time / date intent — direct answers only for explicit requests
# ---------------------------------------------------------------------------
def _is_time_question(text: str) -> bool:
    from ..time_intent import is_explicit_time_question

    return is_explicit_time_question(text)


def _time_answer(text: str) -> str:
    """Concise local-clock answer; no timestamp/date extras unless they were requested."""
    from datetime import datetime, timedelta, timezone

    from ..timezone import configured_timezone

    tz = configured_timezone()
    low = (text or "").lower()
    now = datetime.now(tz)
    if any(k in low for k in ("beeta kal", "bita kal", "guzra kal", "yesterday")):
        target, label = now - timedelta(days=1), "Kal (beeta)"
    elif any(k in low for k in ("parso", "parson", "day after tomorrow")):
        target, label = now + timedelta(days=2), "Parso"
    elif any(k in low for k in ("kal", "tomorrow")):
        target, label = now + timedelta(days=1), "Kal"
    else:
        target, label = now, "Aaj"

    time_words = ("time", "samay", "baje", "baj", "clock", "ghadi", "utc", "timezone", "time zone")
    date_words = ("date", "tareekh", "tarikh", "din", "day", "tomorrow", "yesterday", "kal", "parso")
    want_time = any(word in low for word in time_words)
    want_date = any(word in low for word in date_words)
    if not want_time and not want_date:
        want_time = True

    lines: list[str] = []
    if want_time:
        local_time = target.strftime("%I:%M %p")
        if "utc" in low:
            lines.append(f"{label}: {target.astimezone(timezone.utc).strftime('%I:%M %p')} UTC.")
        elif target.date() == now.date():
            lines.append(f"Abhi {local_time} ({target.tzname() or 'local'}) hai.")
        else:
            lines.append(f"{label}, {local_time} ({target.tzname() or 'local'}).")
    if want_date:
        lines.append(f"{label}: {target.strftime('%A, %d %B %Y')}.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# fast-path handlers (LLM se pehle deterministic kaam — sasta + bharosemand)
# ---------------------------------------------------------------------------
_GREETING_RX = re.compile(
    r"^(?:hi+|hey+|hello+|hy+|yo|namaste|namaskar|good\s+morning|good\s+afternoon|good\s+evening)"
    r"(?:\s+(?:jarvis|bhai|boss|there))?"
    r"(?:\s*(?:how\s+are\s+you|how\s+r\s+u|kaise\s+ho|kaisa\s+hai))?$",
    re.I,
)


def is_trivial_greeting(text: str) -> bool:
    normalized = re.sub(r"[^\w\s]", " ", (text or "").lower(), flags=re.UNICODE)
    normalized = " ".join(normalized.split())
    return bool(normalized and len(normalized.split()) <= 7 and _GREETING_RX.fullmatch(normalized))


async def _fast_paths(text: str, session_id: str, surface: str) -> AgentResult | None:
    from ..config import runtime as R
    from ..memory.manager import get_manager, is_memory_request, strip_trigger

    started = time.time()
    low = text.lower().strip()

    # 0) time / date — local clock, koi LLM nahi (hallucination-proof)
    if _is_time_question(low):
        answer = _time_answer(text)
        return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                           surface=surface, seconds=time.time() - started, status="time",
                           workers=["clock"], reasoning=["ACTION: local clock read",
                                                      "RESULT: time/date local system clock se (IST + UTC)"])

    # 0.5) trivial greetings — zero provider/DSPy/graph calls
    if is_trivial_greeting(text):
        owner = R.get("owner_name", S.OWNER_NAME)
        answer = f"Hey {owner}! Main yahin hoon."
        return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                           surface=surface, seconds=time.time() - started, status="chat",
                           workers=["direct"], reasoning=["DECISION: trivial greeting; no model/tool call"])

    # Sensitive memory saves are staged; resolve only a clear owner yes/no reply.
    confirmation_text = " ".join(re.sub(r"[,;:.!?]+", " ", low).split())
    confirmation_rx = (r"(?:yes|y|haan|han|ha|confirm|confirm karo|haan save karo|yes save it|save it|"
                       r"nahi|nahin|no|cancel|cancel karo|mat save karo|nahi mat save karo|"
                       r"don't save|do not save)")
    if re.fullmatch(confirmation_rx, confirmation_text):
        try:
            pending_manager = get_manager()
            pending_items = pending_manager.pending()
            if pending_items:
                if len(pending_items) > 1:
                    lines = [f"• pending ID: {item.get('id', '')}" for item in pending_items]
                    if surface == "api":
                        guidance = "GET /memory mein pending IDs dekho, phir POST /memory par action=confirm ya cancel aur exact id bhejo."
                    elif surface.startswith("telegram"):
                        guidance = "/memory pending dekho, phir /memory confirm <id> ya /memory cancel <id> chalao."
                    else:
                        guidance = "Pehle memory list mein exact pending ID chuno; main andaze se kisi ko save/cancel nahi karunga."
                    answer = ("Ek se zyada sensitive memory confirmations pending hain; koi item nahi badla. "
                              + guidance + "\n" + "\n".join(lines))
                    return AgentResult(text, answer, spoken=summary_for_speech(answer), session_id=session_id,
                                       surface=surface, seconds=time.time() - started, status="needs_user",
                                       workers=["memory"])
                confirmed = confirmation_text in {
                    "yes", "y", "haan", "han", "ha", "confirm", "confirm karo",
                    "haan save karo", "yes save it", "save it",
                }
                resolved = pending_manager.confirm_pending(
                    confirmed=confirmed, pending_id=str(pending_items[0].get("id") or ""),
                )
                answer = resolved.get("message", "Memory confirmation process nahi ho paaya.")
                return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                                   surface=surface, seconds=time.time() - started,
                                   status="memory" if resolved.get("ok") else "failed",
                                   workers=["memory"], memory_updates=[resolved.get("action", "")])
        except Exception:
            pass

    # 1) memory operations
    op = is_memory_request(text)
    if op:
        if op in {"remember", "forget", "update"}:
            from ..security.permissions import check as permission_check

            if not permission_check("remember_fact", surface).allowed:
                answer = "🔒 Is interface par memory badalne ki permission nahi hai. Kuch save/delete/update nahi hua."
                return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                                   surface=surface, seconds=time.time() - started, status="blocked",
                                   workers=["permissions"], blocked_tools=["remember_fact"])
        mgr = get_manager()
        if op == "remember":
            res = mgr.remember(strip_trigger(text))
            answer = ("🧠 " if res.get("ok") else "⚠️ ") + res["message"]
            return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                               surface=surface, seconds=time.time() - started,
                               status="needs_user" if res.get("action") == "pending_confirmation" else "memory",
                               workers=["memory"], memory_updates=[res.get("action", "")])
        if op == "forget":
            if surface == "voice_owner":
                from ..security.gate import request_human_approval

                approval = await request_human_approval(
                    f"forget memory: {strip_trigger(text)[:180]}", "memory", surface=surface,
                    reason="spoken confirmation required before deleting memory",
                )
                if not approval.allowed:
                    answer = "Memory delete cancel kiya; clear haan nahi mila. Kuch delete nahi hua."
                    return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                                       surface=surface, seconds=time.time() - started, status="cancelled",
                                       workers=["memory"], errors=[approval.reason])
            res = mgr.forget(text)
            answer = ("🗑️ " if res.get("ok") else "🧐 ") + res["message"]
            return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                               surface=surface, seconds=time.time() - started, status="memory",
                               workers=["memory"])
        if op == "update":
            from ..config import runtime as rt

            # setting jaisi update? → turant apply
            m = __import__("re").search(r"(?:set|kar do|karo|rakho|badal)\s+([a-z_]+)\s*[:=]?\s*(\S+)", low)
            if m and m.group(1) in rt.SCHEMA:
                applied, errors = rt.set_many(**{m.group(1): m.group(2)})
                answer = (f"✅ setting `{m.group(1)}` = {list(applied.values())[0]}" if applied
                          else f"⚠️ {'; '.join(errors)}")
                return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                                   surface=surface, seconds=time.time() - started, status="settings",
                                   workers=["settings"])
            res = mgr.update_by_query(text, strip_trigger(text))
            answer = ("♻️ " if res.get("ok") else "⚠️ ") + res["message"]
            return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                               surface=surface, seconds=time.time() - started, status="memory",
                               workers=["memory"])
        if op == "list":
            rows = mgr.list_memories(limit=20)
            body = "\n".join(f"{i}. [{r['kind']}] {r['text'][:110]}" for i, r in enumerate(rows, 1)) or "khali"
            answer = f"🧠 Memory ({len(rows)}):\n{body}"
            return AgentResult(text, answer, spoken=f"Aapki {len(rows)} memories hain.",
                               session_id=session_id, surface=surface,
                               seconds=time.time() - started, status="memory", workers=["memory"])

    # 2) pure settings / mode commands natural language me
    if __import__("re").search(r"\b(mode|model|provider|owner name|language|personality)\b", low) and \
            __import__("re").search(r"\b(badal|set|karo|kar do|change)\b", low):
        import re as _re

        mgr_pairs: dict[str, str] = {}
        # mode: text|voice|telegram
        if _re.search(r"\bmode\b", low):
            mm = _re.search(r"\b(text|voice|telegram)\b", low)
            if mm:
                mgr_pairs["mode"] = mm.group(1)
        # provider names
        if _re.search(r"\bprovider\b", low):
            pp = _re.search(r"\b(gemini|openrouter|groq|openai|anthropic|xai|ollama|auto)\b", low)
            if pp:
                mgr_pairs["provider"] = pp.group(1)
        # language
        if _re.search(r"\b(language|bhasha)\b", low):
            ll = _re.search(r"\b(hindi|english|hinglish)\b", low)
            if ll:
                mgr_pairs["language"] = ll.group(1)
        # model: explicit "model X" pattern
        m = _re.search(r"\bmodel\b\s*(?:ko|=|:)?\s*([\w./:-]{4,60})", low)
        if m and m.group(1).lower() not in {"badal", "badlo", "change", "karo", "set"}:
            mgr_pairs["model"] = m.group(1)
        m2 = _re.search(r"owner\s*naam\s*([\w .]{2,40})", low)
        if m2:
            mgr_pairs["owner_name"] = m2.group(1).strip()
        if mgr_pairs:
            from ..security.permissions import check as permission_check

            if not permission_check("settings", surface).allowed:
                answer = "🔒 Is interface par runtime settings badalne ki permission nahi hai. Koi setting change nahi hui."
                return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                                   surface=surface, seconds=time.time() - started, status="blocked",
                                   workers=["permissions"], blocked_tools=["settings"])
            applied, errors = R.set_many(**mgr_pairs)
            if applied:
                try:
                    from ..llm import reset_cache

                    reset_cache()
                except Exception:
                    pass
            answer = ("✅ " + ", ".join(f"{k}={v}" for k, v in applied.items())) if applied else f"⚠️ {'; '.join(errors)}"
            return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                               surface=surface, seconds=time.time() - started, status="settings",
                               workers=["settings"])
    return None


_COMPOUND_TASK_INTENT_RX = re.compile(
    r"\b(?:search|research|find|dhoondh|compare|weather|mausam|news|price|calculate|code|script|"
    r"create|save|read|download|upload|send|mail|message|play|click|press|run|execute|focus|screenshot)\b",
    re.I,
)


def _has_unhandled_compound_task(text: str, detect_action) -> bool:
    """Do not fast-path an app open if a later actionable clause would be discarded."""
    clauses = re.split(r"\b(?:and|aur|then|phir|uske\s+baad)\b", text or "", flags=re.I)
    if len(clauses) < 2:
        return False
    for clause in clauses:
        if detect_action(clause).get("actions"):
            continue
        if _COMPOUND_TASK_INTENT_RX.search(clause):
            return True
    return False


async def _direct_app_request(text: str, session_id: str, surface: str, emit) -> AgentResult | None:
    """Handle clear ordered app actions; leave mixed compound tasks intact for graph planning."""
    try:
        from ..graph.nodes import _desktop_tools_and_blocked, _execute_desktop_action, detect_desktop_action
    except Exception:
        return None
    action = detect_desktop_action(text)
    actions = action.get("actions") or []
    if not actions or not any(a.get("kind") == "open_app" for a in actions):
        return None
    if _has_unhandled_compound_task(text, detect_desktop_action):
        return None
    if len(actions) > 6 or any(a.get("kind") not in {"open_app", "type_text"} for a in actions):
        return None

    from ..security.permissions import check as permission_check

    required = {"open_app" if a.get("kind") == "open_app" else "type_text" for a in actions}
    denied = [name for name in required if not permission_check(name, surface).allowed]
    if denied:
        answer = f"🔒 Is interface par app/desktop control allowed nahi ({', '.join(denied)}). Koi app launch nahi kiya."
        return AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                           surface=surface, status="blocked", workers=["permissions"],
                           blocked_tools=denied, execution_required=True,
                           errors=["desktop action blocked by surface permission"])

    tools, _ = _desktop_tools_and_blocked(surface)
    plan = ["Identify the requested application", "Focus its existing window or launch it once"]
    if any(a.get("kind") == "type_text" for a in actions):
        plan.append("Type the requested text only after the app action returns")
    emit("plan", f"Direct desktop action ({len(actions)} step(s))", detail=" → ".join(plan))
    calls = await _execute_desktop_action(action, tools)
    failures = [c for c in calls if not c.get("ok")]
    outputs = [str(c.get("output") or "").strip() for c in calls]
    if failures:
        answer = "⚠️ App request verify nahi hua; maine success claim nahi ki.\n" + "\n".join(
            f"• {c.get('name')}: {str(c.get('output') or '')[:240]}" for c in failures[:3])
        status = "partial_failure" if len(failures) < len(calls) else "failed"
    else:
        answer = "\n".join(out for out in outputs if out) or "⚠️ Tool ne koi result nahi diya; launch verify nahi hua."
        status = "done" if outputs else "failed"
    result = AgentResult(
        text, answer, spoken=summary_for_speech(answer), plan=plan, workers=["desktop"],
        reasoning=["DECISION: clear app-open intent; skipped LLM planning",
                   f"ACTION: {len(calls)} actual desktop tool call(s)",
                   f"VERIFICATION: {len(calls) - len(failures)} ok, {len(failures)} failed"],
        findings=[{"worker": "desktop", "summary": answer, "tool_calls": calls}],
        errors=[str(c.get("output") or "desktop action failed") for c in failures],
        status=status, tool_evidence=calls, execution_required=True,
        session_id=session_id, surface=surface,
    )
    result.recompute_execution_flags()
    return result



_CHAT_TASK_ACTION_RX = re.compile(
    r"\b(?:open(?![-\s]+source)|opens|opened|close|closes|closed|launch\w*|start\w*|type|write|save|delete|remove|rename|"
    r"move|install|download|upload|search|research|look\s+up|browse|scrape|fetch|find|locate|compare|google|"
    r"press|click|execute|run|send|message|schedule|remind(?:er)?|remember|forget|create|make|build|read|copy|"
    r"paste|edit|screenshot|kholo|khol(?:o|na|ke|kar)?|kholke|krke|karke|kar\s+ke|kar\s+do|karo|"
    r"banao|bana(?:\s+do|\s+ke)?|likho|likh(?:\s+do|\s+de|\s+ke)?|hatao|chalao|chala\s+do|bhejo|"
    r"dhundo|dhoondo|dhoondho|dhoondh(?:o|ho)?|dikhao|band\s+kar(?:o|do)?"
    r")\b",
    re.I,
)
_CHAT_INSTRUCTION_RX = re.compile(
    r"\b(?:how\s+(?:do|can|should)\s+i|how\s+to|kaise|kaisay|steps\s+to|explain|tutorial)\b", re.I
)
_CHAT_CURRENT_FACT_RX = re.compile(
    r"\b(?:latest|current|live|today'?s\s+(?:weather|news|price)|near\s+me|nearby)\b", re.I
)
_CHAT_ASSET_RX = (
    r"notepad|chrome|browser|calculator|explorer|vs\s*code|vscode|desktop|folder|folders|file|files|"
    r"notes?\.(?:txt|md|json|csv)|[\w.-]+\.(?:txt|md|json|csv|pdf|docx|xlsx)"
)
_CHAT_ASSET_LOOKUP_RX = re.compile(
    rf"\b(?:where(?:'s|\s+is|\s+are)?|kahan|kidhar|locate|find|list|show|open|read|search\s+for|"
    rf"what(?:'s|\s+is)\s+in|mere\s+(?:desktop|folder|file)|my\s+(?:desktop|folder|file)|"
    rf"on\s+(?:my\s+)?desktop|in\s+(?:my\s+)?folder)\b.{{0,80}}\b(?:{_CHAT_ASSET_RX})\b",
    re.I,
)
_CHAT_CURRENT_DATA_RX = re.compile(r"\b(?:weather|mausam|forecast|latest\s+news|stock\s+price|prices?)\b", re.I)
_CHAT_CLEAR_CONVERSATION_RX = re.compile(
    r"\b(?:thanks?|thank\s+you|shukriya|dhanyavaad|i\s+(?:am|['’]m|feel|felt|think|love|like|hate|"
    r"need\s+(?:(?:a\s+little|some|more)\s+)?(?:motivation|encouragement|support|reassurance))|what\s+do\s+you\s+think|"
    r"what\s+is\s+your\s+take|do\s+you\s+like|how\s+are\s+you|how\s+r\s+u|"
    r"that\s+(?:.{0,30}\b(?:was|is)\b.{0,25}\b(?:funny|good|great|nice)\b|"
    r"made\s+me\s+(?:laugh|smile))|"
    r"you\s+made\s+me\s+(?:laugh|smile)|i\s+had\s+.*\s+day|"
    r"i(?:['’]m|\s+am)\s+(?:feeling|feel|bored|tired|nervous|excited|happy|sad|anxious|proud)|"
    r"i\s+(?:finally\s+)?(?:finished|read|watched|heard|enjoyed)\b|i\s+was\s+thinking\b|"
    r"my\s+day\s+(?:was|has\s+been|is)\b|mujhe\s+.*(?:motivation|encouragement|pasand)|"
    r"kya\s+(?:scene|haal)|mood\s+.*\s+off|just\s+chat|bas\s+baat|baat\s+karo)\b",
    re.I,
)
_CHAT_CONVERSATION_OVERRIDE_RX = re.compile(
    r"\b(?:no\s+questions\s*,?\s*just\s+chat|mat\s+poocho\s*,?\s*(?:bas\s+)?baat\s+karo|"
    r"bas\s+mu[j]?h?se\s+baat\s+karo|just\s+chat\s+with\s+me|chat\s+karo)\b",
    re.I,
)
_CHAT_GENERAL_QUESTION_RX = re.compile(
    r"^(?:who|what|when|where|why|which|how|is|are|do|does|did|can\s+you\s+tell\s+me|tell\s+me|"
    r"explain|kya|kaun|kyun|kaise|what['’]s|who['’]s)\b",
    re.I,
)
_CHAT_DIRECT_ACTION_REQUEST_RX = re.compile(
    r"^(?:(?:please|plz|jarvis|boss|bhai)[,\s]+)*(?:open|close|launch|start|type|write|save|delete|remove|"
    r"rename|move|install|download|upload|search|find|browse|run|execute|send|create|make|build|click|press|"
    r"kholo|khol|kholke|krke|karke|kar\s+do|karo|banao|bana\s+do|likho|likh\s+do|hatao|chalao|bhejo|"
    r"dhundo|dhoondo)\b|\b(?:can|could|would)\s+you\s+(?:please\s+)?(?:open|close|launch|start|type|write|"
    r"save|delete|remove|rename|move|install|download|upload|search|find|run|execute|send|create|make|build)\b",
    re.I,
)


def is_chat_request(text: str) -> bool:
    """Default to task; use the one-call chat path only for clearly conversational input."""
    low = " ".join((text or "").strip().lower().split())
    if not low or _is_time_question(low):
        return False
    if is_trivial_greeting(text):
        return True
    if _CHAT_CONVERSATION_OVERRIDE_RX.search(low):
        return True
    if _CHAT_INSTRUCTION_RX.search(low) and not _CHAT_DIRECT_ACTION_REQUEST_RX.search(low) \
            and not re.search(r"\b(?:for me|mere liye|do it|please do|kar do|karo)\b", low):
        return True
    if _CHAT_TASK_ACTION_RX.search(low) or _CHAT_CURRENT_FACT_RX.search(low) \
            or _CHAT_CURRENT_DATA_RX.search(low) or _CHAT_ASSET_LOOKUP_RX.search(low):
        return False
    if _CHAT_CLEAR_CONVERSATION_RX.search(low):
        return True
    if _CHAT_GENERAL_QUESTION_RX.search(low):
        return True
    # An unfamiliar imperative/request is safer in the task pipeline than as an unverified chat answer.
    return False


async def _chat_fast_path(text: str, session_id: str, surface: str, emit) -> AgentResult:
    """One-model-call chat path; no graph routing, planner, tools, synthesis, or critic."""
    from langchain_core.messages import HumanMessage, SystemMessage

    from ..llm import get_chat_model
    from ..memory.store import get_memory
    from ..prompts import chat_system_prompt

    started = time.monotonic()
    memory_context = ""
    follow_up_allowed = True
    try:
        memory = get_memory()
        recent = memory.recent(limit=8, session=session_id)
        memory_context = memory.relevant_context(
            text, token_budget=420, limit=5, session=session_id, recent_limit=6,
        )
        recent_assistant = [row for row in recent[-8:] if row.get("role") == "assistant"]
        follow_up_allowed = not any("?" in str(row.get("content") or "") for row in recent_assistant[-3:])
    except Exception:
        memory_context = ""

    if re.search(r"\b(?:mat\s+poocho|mat\s+puchho|don't\s+ask|do\s+not\s+ask|no\s+questions)\b", text, re.I):
        follow_up_allowed = False

    prompt = chat_system_prompt(follow_up_allowed=follow_up_allowed)
    messages = [SystemMessage(content=prompt)]
    if memory_context:
        messages.append(SystemMessage(content=memory_context))
    messages.append(HumanMessage(content=text))

    label = "brain/chat"
    emit("model_start", "Chat reply started", tool=label, status="running")
    try:
        response = await get_chat_model("brain").ainvoke(messages)
        content = getattr(response, "content", response)
        if isinstance(content, list):
            content = " ".join(str(part.get("text", "")) if isinstance(part, dict) else str(part)
                                for part in content)
        answer = str(content or "").strip()
        if not answer:
            raise ValueError("chat model returned an empty reply")
    except Exception as exc:
        elapsed = int((time.monotonic() - started) * 1000)
        emit("model_end", "Chat reply unavailable", tool=label, ms=elapsed, status="fail")
        answer = "Abhi chat reply generate nahi ho paaya; request fail hui hai, main guess nahi karunga."
        result = AgentResult(text, answer, spoken=for_speech(answer), session_id=session_id,
                             surface=surface, seconds=time.monotonic() - started, status="failed",
                             workers=["chat"], errors=[f"chat model: {type(exc).__name__}: {str(exc)[:180]}"])
        result.events = [{"node": "chat", "status": "failed", "ms": elapsed}]
        return result

    elapsed = int((time.monotonic() - started) * 1000)
    emit("model_end", "Chat reply ready", tool=label, ms=elapsed, status="ok")
    emit("trace", "route=chat · planner=skipped · tools=0 · critic=skipped", ms=elapsed, status="ok")
    result = AgentResult(
        text, answer, spoken=summary_for_speech(answer, max_sentences=3), session_id=session_id,
        surface=surface, seconds=time.monotonic() - started, status="chat", workers=["chat"],
        reasoning=["DECISION: conversational request; direct chat path", "ACTION: one brain call; no tools/planner/critic"],
    )
    result.events = [{"node": "chat", "status": "done", "ms": elapsed, "llm_calls": 1,
                     "tools": 0, "planner": "skipped", "critic": "skipped"}]
    return result


# ---------------------------------------------------------------------------
# main entry
# ---------------------------------------------------------------------------
async def run_agent(
    text: str,
    session_id: str = "cli",
    surface: str = "cli_owner",
    use_fast_path: bool = True,
    voice_output: bool = False,
    on_progress: Any = None,
    memory_user_id: str = "nikhil_mehra",
    run_id: str | None = None,
) -> AgentResult:
    """Ek request chalao — fast paths → LangGraph → structured result.

    `on_progress`: optional callable(ProgressEvent) — CLI/Telegram real phase/tool/model
    status dikhate hain. Owner modes share one memory; guest identities get isolated stores.
    """
    started = time.time()
    from ..memory.session_state import use_state_user
    from ..memory.store import use_memory_user
    from ..security.permissions import use_surface
    from .progress import CallbackSink, emit, use_sink

    with use_memory_user(memory_user_id), use_state_user(memory_user_id), use_surface(surface):
        result = await _run_agent_inner(text, session_id, surface, use_fast_path, voice_output,
                                        started, on_progress, CallbackSink, emit, use_sink, run_id)
    result.run_id = str(run_id or result.run_id or "")
    return result


async def _run_agent_inner(text, session_id, surface, use_fast_path, voice_output,
                           started, on_progress, CallbackSink, emit, use_sink, run_id=None):
    # agar caller ne apna callback diya to wahi sink use karo, warna bahar wala (contextvar) sink
    sink = CallbackSink(on_progress) if on_progress else None
    if sink is None:
        emit("start", f"Request mila: {text[:80]}", detail=text)
        return await _run_agent_body(text, session_id, surface, use_fast_path, voice_output,
                                     started, emit, run_id)
    with use_sink(sink):
        emit("start", f"Request mila: {text[:80]}", detail=text)
        return await _run_agent_body(text, session_id, surface, use_fast_path, voice_output,
                                     started, emit, run_id)


async def _run_agent_body(text, session_id, surface, use_fast_path, voice_output, started, emit, run_id=None):
    text = (text or "").strip()
    if not text:
        return AgentResult(text, "kuch bola nahi 😅", session_id=session_id, surface=surface)

    result = AgentResult(text, session_id=session_id, surface=surface)
    emit("thinking", "Samajh raha hoon + memory check kar raha hoon…")

    # session state: task log (loop prevention ke liye)
    try:
        get_state().add_task(text[:200], workers=[], status="running")
    except Exception:
        pass

    if use_fast_path:
        emit("thinking", "Fast-path check (commands / registry / session state)…")
        fast = await _fast_paths(text, session_id, surface)
        if fast is not None:
            fast.seconds = time.time() - started
            _post_run(fast, session_id, emit=emit)
            fast.seconds = time.time() - started
            _emit_final_status(emit, fast)
            return fast

        if is_chat_request(text):
            chat = await _chat_fast_path(text, session_id, surface, emit)
            chat.seconds = time.time() - started
            _post_run(chat, session_id, emit=emit)
            chat.seconds = time.time() - started
            _emit_final_status(emit, chat)
            return chat

        direct = await _direct_app_request(text, session_id, surface, emit)
        if direct is not None:
            direct.seconds = time.time() - started
            _post_run(direct, session_id, emit=emit)
            direct.seconds = time.time() - started
            _emit_final_status(emit, direct)
            return direct

    if not use_fast_path and is_chat_request(text):
        chat = await _chat_fast_path(text, session_id, surface, emit)
        chat.seconds = time.time() - started
        _post_run(chat, session_id, emit=emit)
        chat.seconds = time.time() - started
        _emit_final_status(emit, chat)
        return chat

    try:
        from ..graph.build import jarvis_ainvoke

        emit("thinking", "LangGraph workflow start (recall → route → plan → act → verify)…")
        state = await jarvis_ainvoke(text, session_id=session_id, surface=surface, run_id=run_id)
        result.answer = state.get("answer") or state.get("response") or ""
        result.plan = state.get("plan") or []
        result.workers = state.get("workers") or []
        result.findings = state.get("findings") or []
        result.artifacts = state.get("artifacts") or []
        result.errors = state.get("errors") or []
        result.blocked_tools = state.get("blocked_tools") or []
        result.iterations = state.get("iterations") or 0
        result.critique = state.get("critique") or {}
        result.requirements = state.get("requirements") or {}
        result.events = state.get("events") or []
        from ..graph.synthesis import build_reasoning_summary

        result.reasoning = state.get("reasoning_summary") or build_reasoning_summary(state)
        result.status = state.get("status") or "done"
        result.memory_persisted = bool(state.get("memory_persisted"))
        result.task_id = str(state.get("task_id") or "")
        # evidence-based flags (hard invariant) — state se, guess se nahi
        from ..runtime.evidence import evidence_records, is_tool_required

        result.tool_evidence = evidence_records(state)[:24]
        result.execution_required = bool(is_tool_required(state, workers=result.workers))
        result.recompute_execution_flags()
        plan_lines = [str(x) for x in (result.plan or [])][:6]
        if plan_lines:
            emit("plan", f"{len(result.plan)} step plan tayyar", detail=" | ".join(plan_lines))
        calls_ = [c for f in (result.findings or []) for c in (f.get("tool_calls") or [])]
        if calls_:
            failed = [c for c in calls_ if not c.get("ok", True)]
            emit("verify", f"{len(calls_)} tool call verify — {len(failed)} fail",
                 status="fail" if failed else "ok")
        spoken = state.get("spoken") or ""
        result.spoken = for_speech(spoken) if spoken else summary_for_speech(result.answer)
    except Exception as exc:
        result.status = "error"
        result.errors = [str(exc)]
        result.verified_execution = False
        emit("error", f"Agent crash: {type(exc).__name__}: {str(exc)[:160]}", status="fail")
        result.answer = (f"⚠️ Agent chalane me dikkat aayi: {str(exc)[:300]}\n"
                         "Try: `python -m jarvis doctor` (config check) ya `python -m jarvis doctor --fix`.")
        result.spoken = for_speech(result.answer)

    if voice_output and not result.spoken:
        result.spoken = summary_for_speech(result.answer)
    _post_run(result, session_id, emit=emit)
    result.seconds = time.time() - started
    _emit_final_status(emit, result)
    return result


def _emit_final_status(emit, result: AgentResult) -> None:
    """Terminal progress must match the result; an error never becomes a green done event."""
    status = (result.status or "").lower()
    elapsed_ms = int(max(0.0, result.seconds) * 1000)
    if status in {"failed", "error", "blocked", "cancelled"}:
        emit("error", f"Request {status}; kaam complete nahi hua", status="fail", ms=elapsed_ms)
    elif status in {"needs_clarification", "needs_user"}:
        emit("warn", "Clarification requested; action has not run yet", status="skipped", ms=elapsed_ms)
    elif result.errors or status in {"partial_failure", "done_with_errors"}:
        emit("warn", f"Request finished with {len(result.errors)} error(s)", status="fail", ms=elapsed_ms)
    else:
        emit("done", f"Request complete ({result.seconds:.1f}s)", status="ok", ms=elapsed_ms)


def _post_run(result: AgentResult, session_id: str, emit=None) -> None:
    """Persist one turn, close one task row, and surface every persistence failure."""
    def persistence_error(where: str, exc: Exception) -> None:
        msg = f"{where} failed ({type(exc).__name__}: {str(exc)[:120]})"
        if msg not in result.errors:
            result.errors.append(msg)
        if result.status not in {"failed", "error", "blocked", "cancelled", "needs_user"}:
            result.status = "partial_failure"
        if emit:
            emit("error", msg, status="fail")

    if result.errors and result.status not in {"failed", "error", "blocked", "cancelled", "needs_user", "partial_failure"}:
        result.status = "partial_failure"
    mem = None
    try:
        from ..memory.store import get_memory
        mem = get_memory()
    except Exception as exc:
        persistence_error("memory store initialization", exc)

    if mem is not None and not result.memory_persisted:
        try:
            mem.add_turn(result.request, result.answer[:1500], session=session_id)
            result.memory_persisted = True
            if emit:
                emit("thinking", "Conversation turn saved to shared memory store")
        except Exception as exc:
            persistence_error("conversation memory persistence", exc)

    if mem is not None and not result.task_id:
        try:
            result.task_id = mem.start_task(result.request, route=",".join(result.workers)) or ""
        except Exception as exc:
            persistence_error("task creation", exc)
    if mem is not None and result.task_id:
        try:
            mem.finish_task(result.task_id, result.status, result=result.answer[:1200],
                            plan=result.plan, artifacts=result.artifacts, requirements=result.requirements)
        except Exception as exc:
            persistence_error("task finalization", exc)

    # Update the single short-term task row created before the graph started.
    try:
        state = get_state()
        state.finish_task(status=result.status, result=result.answer[:300], artifacts=result.artifacts)
        if result.errors:
            state.remember_error(str(result.errors[0])[:200])
    except Exception as exc:
        persistence_error("session-state finalization", exc)

    if result.errors and result.status not in {"failed", "error", "blocked", "cancelled", "needs_user", "partial_failure"}:
        result.status = "partial_failure"
    try:
        from ..llm import model_attempts

        result.events = list(result.events) + [{"node": "model_attempts", "events": model_attempts(5)}]
    except Exception:
        pass


async def stream_agent(
    text: str,
    session_id: str = "cli",
    surface: str = "cli_owner",
    memory_user_id: str = "nikhil_mehra",
    use_fast_path: bool = True,
    voice_output: bool = False,
    run_id: str | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Stream progress from the same runner as one-shot calls (fast paths + user context included)."""
    queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def on_progress(event) -> None:
        payload = asdict(event) if hasattr(event, "__dataclass_fields__") else dict(event)
        loop.call_soon_threadsafe(queue.put_nowait, {
            "node": "progress", "update_keys": ["events"], "events": [payload], "event": payload,
        })

    async def run() -> AgentResult:
        try:
            return await run_agent(
                text,
                session_id=session_id,
                surface=surface,
                use_fast_path=use_fast_path,
                voice_output=voice_output,
                on_progress=on_progress,
                memory_user_id=memory_user_id,
                run_id=run_id,
            )
        finally:
            loop.call_soon_threadsafe(queue.put_nowait, None)

    task = asyncio.create_task(run())
    try:
        while True:
            chunk = await queue.get()
            if chunk is None:
                break
            yield chunk
        result = await task
        yield {
            "node": "final",
            "answer": result.answer,
            "spoken": result.spoken,
            "status": result.status,
            "result": result.as_dict(),
        }
    finally:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
